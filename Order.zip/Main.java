import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String input = scanner.nextLine();
        List<Order> people = new ArrayList<>();

        while (!"End".equals(input)) {
            String[] data = input.split(" ");
            String name = data[0];
            String id = data[1];
            int age = Integer.parseInt(data[2]);

            Order order = new Order(name, id, age);
            people.add(order);

            input = scanner.nextLine();
        }

        people
                .stream()
                .sorted(Comparator.comparingInt(Order::getAge))
                .forEach(e ->
                        System.out.println(e.toString())
                );

    }
}
