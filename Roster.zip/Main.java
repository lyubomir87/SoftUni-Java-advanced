import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());
        HashMap<String, Department> departments = new HashMap<>();
        for (int i = 0; i < n; i++) {
            String[] data = scanner.nextLine().split("\\s+");
            String name = data[0];
            double salary = Double.parseDouble(data[1]);
            String position = data[2];
            String department = data[3];
            Employee employee = new Employee(name, salary, position);
            if (data.length == 4) {
                employee.setName(name);
                employee.setSalary(salary);
                employee.setPosition(position);


            }


            if (data.length == 5) {
                String def = data[4];
                char a = def.charAt(0);
                if (Character.isDigit(a)) {
                    int age = Integer.parseInt(data[4]);
                    employee.setAge(age);


                } else {
                    String email = data[4];
                    employee.setEmail(email);

                }
            } else if (data.length == 6) {
                String mail = data[4];
                int age = Integer.parseInt(data[5]);
                employee.setEmail(mail);
                employee.setAge(age);

            }
            if (!departments.containsKey(department)) {
                departments.put(department, new Department());

            }
            departments.get(department).addEmployee(employee);
        }
        Map.Entry<String, Department> highesAvgSalary = departments.entrySet().stream().sorted((f, s) -> {
            int result = 0;
            if (s.getValue().getAverageSalary() > f.getValue().getAverageSalary()) {
                result = 1;
            } else if (s.getValue().getAverageSalary() < f.getValue().getAverageSalary()) {
                result = -1;
            }
            return result;
        }).findFirst()
                .get();

        System.out.println(String.format("Highest Average Salary: %s", highesAvgSalary.getKey()));

        highesAvgSalary.getValue().getEmployees().stream().
                sorted((f, s) -> Double.compare(s.getSalary(), f.getSalary()))
                .forEach(employee -> {
                    System.out.println(String.format("%s %.2f %s %d", employee.getName(),
                            employee.getSalary(), employee.getEmail(), employee.getAge()));
                });


    }
}
