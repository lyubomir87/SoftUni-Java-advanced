import java.util.ArrayList;

import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = Integer.parseInt(scanner.nextLine());
        List<Student> people = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            String input = scanner.nextLine();
            String[] data = input.split("\\s+");
            String firstname = data[0];
            String secondName = data[1];
            double grade = Double.parseDouble(data[2]);

            Student student = new Student(firstname, secondName, grade);
            people.add(student);
        }
        people
                .stream()
                .sorted((p1, p2) -> Double.compare(p2.getGrade(), p1.getGrade())).
                forEach(e ->
                        System.out.println(e.toString()));
    }


}
