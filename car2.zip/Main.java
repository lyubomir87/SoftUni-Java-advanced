import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int carNum = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < carNum; i++) {
            String[] cars = scanner.nextLine().split("\\s+");
            String carMaker = cars[0];

            if (cars.length > 1) {
                String carModel = cars[1];
                int horsePow = Integer.parseInt(cars[2]);
                Car car = new Car(carMaker, carModel, horsePow);

                car.setMake(carMaker);
                car.setModel(carModel);
                car.setHorsePower(horsePow);
                String toString = String.format("The car is: %s %s - %d HP.", car.getMake(), car.getModel(), car.getHorsePower());
                System.out.println(toString);
            } else {
                Car car = new Car(carMaker);
                car.setMake(carMaker);
                String toString = String.format("The car is: %s %s - %d HP.", car.getMake(), car.getModel(), car.getHorsePower());
                System.out.println(toString);
            }


        }

    }
}
